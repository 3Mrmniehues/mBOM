# mBOM UI Redesign Plan — "App Shell" with collapsible sidebars

Status: **proposal / for discussion** (nothing here is built yet). Goal: a
cleaner, more modern UI based on your attached dashboard wireframe, with
collapsible side panels and the Orders tab moved to a collapsible right sidebar.

---

## 1. What you asked for

- A **more user-friendly, cleaner UI**, inspired by the attached dashboard
  wireframe (icon rail on the left, main content in the middle, a panel on the
  right).
- **Collapsible sidebars** — collapse them when you don't need them.
- **Replace the Orders tab with a collapsible right sidebar** (Orders becomes a
  panel instead of a full-page tab).
- Keep everything that already works (BOM tree/flat, filters, selection,
  copy/paste, Excel import/export, HTML export, refresh, etc.).

## 2. Proposed layout — the "app shell"

A CSS-grid shell with three zones around the existing content:

```
┌──────────────────────────── Top bar ─────────────────────────────┐
│ ☰  <Project name> · WBS · EWR        [↻][Import][Export][⋯][Close] │
├──────┬────────────────────────────────────────┬───────────────────┤
│ Left │                                        │   Right panel     │
│ rail │        Main area                       │   ORDERS          │
│      │        Bill of Materials               │   (collapsible)   │
│  ⌂   │        (Tree / Flat)                    │  ┌─────────────┐  │
│  🔍  │                                        │  │ RFx card    │  │
│  ▦   │                                        │  │ RFx card    │  │
│  ⚙   │                                        │  │ (none) …    │  │
│  —   │                                        │  └─────────────┘  │
│  👤  │                                        │        ‹ handle   │
└──────┴────────────────────────────────────────┴───────────────────┘
```

- **Left rail (navigation).** Collapsed = icons only (~56px); expanded = icons +
  labels (~220px). Candidate items: Back to Projects, Search, BOM views
  (Tree/Flat), Project Details, Settings, and a theme toggle + user at the
  bottom. This replaces today's horizontal tab strip + some header buttons.
- **Main area.** The BOM grid, essentially unchanged internally (same render
  functions, same wide horizontal-scroll table).
- **Right panel (Orders).** A collapsible slide-over. Collapsed = hidden behind
  a thin handle/tab on the right edge; expanded = the Orders list. A toggle in
  the top bar opens/closes it.

## 3. How collapsing behaves

- Each sidebar has a toggle (hamburger / chevron). State is **remembered in
  `localStorage`** per browser, so it reopens the way you left it.
- Smooth ~200ms CSS transition on width / transform (no layout jank).
- **Responsive:** under ~1100px the right Orders panel becomes an overlay drawer
  (floats over the BOM instead of squeezing it); under ~800px the left rail
  auto-collapses to icons.
- Optional keyboard shortcuts (e.g. `[` left rail, `]` Orders panel).

## 4. Patterns borrowed from uselayouts.com/browse

useLayouts is a gallery of polished **React + Framer-Motion** micro-components.
mBOM is vanilla JS/CSS, so we adopt the **interaction patterns and motion feel**
(built with CSS transitions + a little JS) — **not** the React code, and with no
new framework dependency. Relevant references:

| useLayouts pattern | Where it informs mBOM |
|---|---|
| **Vertical Tabs** | Left rail with an animated active-item indicator |
| **Curve Drawer**, **Dynamic Toolbar** | The right Orders slide-over + a floating action bar |
| **Smooth Dropdown** | Nicer RFx / Status dropdowns (today native) |
| **Stacked List**, **Bento Card** | Orders rendered as compact cards in the panel |
| **Theme Toggle** | Explicit light/dark/system switch (today it only follows the OS) |
| **Tactile Button**, **Delete Button** | Button micro-interactions / affordances |

## 5. Orders as a right panel (the biggest change)

Today Orders is a full tab with a wide table. As a right sidebar it should be
compact and glanceable:

- A scrollable list of **order cards** — RFx, supplier, a status chip, delivery
  date — plus the existing **"(none)" bucket** card for items with no RFx.
- Clicking an order either (a) expands its parts inline in the card, or (b)
  **filters/highlights the BOM** in the main area to that RFx. *(decision below)*
- Keep **Add Order**, **Copy Table**, **Expand/Collapse All** as panel actions.
- The parts-editing behavior (assign RFx, status, notes, clear notes) carries
  over unchanged — it's the same aggregate-edit code.

## 6. Implementation approach (incremental & low-risk)

The app is one large `js/project.js` IIFE + static HTML + CSS-variable theming,
so we can re-shell it without rewriting the internals. Suggested phases, each
shippable and testable on its own:

- **Phase 0 — shell scaffold.** Wrap the existing content in a CSS-grid
  `.app-shell` (`grid-template-columns: var(--rail-w) 1fr var(--orders-w)`). No
  behavior change yet; the current tabs still work. Pure layout.
- **Phase 1 — left rail.** Convert the tab strip + some header buttons into the
  collapsible left rail; add the toggle + `localStorage` persistence.
- **Phase 2 — right Orders panel.** Move the Orders tab's content into the right
  panel; add collapse + overlay-on-narrow; remove the Orders tab. This is where
  Orders-as-cards (section 5) lands.
- **Phase 3 — polish.** Motion, theme toggle, dropdown styling, button
  affordances, keyboard shortcuts.

Throughout, the **render functions stay the same** (`renderBom`, `renderOrders`,
the aggregate/editable cells), so BOM editing, selection, clipboard, filters,
Excel import/export, and the read-only HTML export keep working.

## 7. Risks / things to preserve

- **The BOM table is wide** and scrolls horizontally; the right panel eats
  width, so it must be collapsible and overlay (not squeeze) on narrow screens.
- **Read-only HTML export** inlines the `project.html` body. The shell must
  degrade gracefully there — the export can keep a simple single-column layout
  with the rails hidden (it has no Orders editing anyway).
- Keep all **keyboard / selection / clipboard** features working inside the new
  main area (they're bound to the BOM grid, which doesn't move).
- Preserve the current **light/dark theming** (CSS variables) — the shell reuses
  the same tokens.

## 8. Open decisions (need your input before building)

1. **Left rail contents** — which items? Do you want a **project switcher** in
   the rail (jump between projects without going back to the home page)?
2. **Orders panel style** — compact **cards** or a condensed **table**? And
   should clicking an order **filter the BOM** to that RFx (cross-highlight)?
3. **Theme toggle** — add an explicit light/dark/system switch in the rail?
4. **Scope** — redesign the **project-detail page** only, or also restyle the
   **project-selector home page** to match (left rail with project list, like
   the wireframe's list column)?

## 9. Suggested next step

Before committing code, I can build a **clickable HTML mockup** of this shell
(collapsible rails, Orders-as-panel) wired to your real data, so you can *feel*
the layout and pick options — then we implement phase by phase from section 6.
