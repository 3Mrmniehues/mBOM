# Changelog

A local project + Bill-of-Materials (BOM) manager: a project selector home
page and a per-project detail page with a full editable BOM, Orders, Excel
import/export, and an Excel data connection — served by a small Python +
SQLite server and launched by a double-click.

This log groups the work by area rather than by date.

## Home page — project selection

- **Project cards** (grid of tiles: WBS badge, name, EWR, created date, status
  pill, **Edit** ✎ and Delete) replacing the old table — searchable and
  status-filterable, with a **Sort** dropdown (newest/oldest, name, WBS, status).
  Click a card to open it, or the **pencil** to edit its details in a dialog.
- **Light / dark theme toggle** (sun/moon button) on both the home and project
  pages — remembers your choice and falls back to the OS setting; native
  dropdowns and date pickers follow it.
- **New Project** dialog with validation and a duplicate-WBS check. Only
  **Project Name** is required — WBS, EWR, Status, and Date Created are
  optional (the WBS duplicate check only runs when a WBS is entered).
- Clicking a row opens the project directly (the separate "Select Project"
  button was removed). Rows open by project **id**, so a blank/shared WBS no
  longer matters for navigation.
- Opens **filtered to Active** by default; the Status field was simplified to
  **Active / Archived**.
- **Delete a project** from its row, via a confirmation dialog that warns the
  deletion is permanent (BOM and Orders included) and offers to **export the
  project to Excel first**. Deletion cascades server-side, leaving no orphaned
  data.
- **Excel Data** button (see *Data storage & Excel connection*).

## Project workspace — app shell

- The project page is an **app shell**: a collapsible **left rail**, the Bill of
  Materials as the main area, and a collapsible **Orders** panel on the right
  (the Orders tab is gone). The old top tabs are removed.
- **Left rail** shows icons only by default; hovering slides the labels out as an
  overlay (the table doesn't move), and the ☰ toggle **pins** it open. Items:
  Home, Refresh, Export HTML, Export Excel, Import Excel, **Settings**, theme
  toggle, Close App. Pin state is remembered.
- **Settings** (⚙) opens **Project Details** (now a dialog) and **BOM Settings**.
- **Orders panel** is a compact **RFx + Description** list (plus the "(none)"
  catch-all). Click a row and a **pop-up form** floats up over the list — PO,
  Supplier, Delivery, Status (editable), order actions (Push Status → BOM, Clear
  Notes, Delete), and the parts on that RFx — **while** the matching BOM lines
  are spotlighted in the Tree (others dimmed, with a "Showing RFx…" banner).
  **Back to list** (or **Esc**) deselects the RFx, closes the form, and clears
  the spotlight. The parts section is a **collapsible** list with its own **Show
  Included-in-Parent** toggle and a **Copy Parts** button that copies that one
  RFx's parts list — **with all the default columns** — to the clipboard for
  Excel. The panel collapses to a thin **Orders** handle; its state is
  remembered, and it overlays the table on narrow screens.

## Bill of Materials

- **Views:** Tree (hierarchical, editable) and Flat (aggregated by part
  number). Grouping *by RFx* now lives on the **Orders** tab — expand an order
  to view and edit its parts — so the earlier standalone PO and RFx BOM views
  were both retired. The Tree view opens **fully collapsed** by default; use
  **Expand All** (or a row's toggle) to drill in.
- **Editing in the aggregated views:** in Flat view (and the Orders parts
  expansion) a change to a part fans out to every underlying BOM line — with a
  confirm popup and a difference summary whenever more than one line is
  affected.
- **Columns:** resizable, sortable, **multi-select** per-column filters (pick
  several values with OR matching, with a search box when the list is long and
  a Clear for the whole column); a show/hide columns menu; and "+ Add Column"
  to pull tree fields into the Flat view.
- The **column header stays pinned** at the top while you scroll the BOM, and
  now always sits above the rows — a cell being edited (e.g. the 3M Part Number
  field) no longer bleeds over the header as its row scrolls underneath.
- **Copy Table** (toolbar) copies the *visible* rows and columns — respecting
  collapse, search, filters, and hidden columns — to the clipboard as
  tab-separated text that pastes straight into Excel, with a confirmation
  toast. Available in Tree and Flat views (and on the Orders tab).
- **Custom columns start hidden** in every BOM view so they don't clutter the
  default layout — show them in Tree view via the Columns menu, or in Flat/RFx
  via "+ Add Column".
- **Fields:** Item No (auto-computed from tree position), Assy, Included in
  Parent, 3M Part Number, Qty, Spare (rolled into quantity totals),
  Manufacturer, Commercial Part No, 3M Supplied, Description, RFx, PO
  (read-only, derived from the RFx's order), Status, Notes, plus user-defined
  custom fields.
- **Included in Parent** makes RFx/PO/Status read-only and inherited from the
  parent assembly. **Checking it writes the parent's effective RFx/PO/Status
  into the line's own data** (previously those were only inherited for display),
  so the stored values match the parent. A **Show Included-in-Parent** toggle
  (Flat view toolbar, and in the Orders detail pop-up) reveals those
  normally-hidden lines — in Flat view they join the aggregation; in an order's
  parts list they appear under their effective (inherited) RFx.
- **Row actions** consolidated into a 3-dots menu: Move Up/Down, **Move
  before…/after…**, Insert Above/Below, **Insert Rows…** (a dialog asks how
  many blank rows to drop in below the line), Add Sub-Item, Indent, Outdent,
  Delete. Larger expand/collapse handles.
- **Select lines + bulk actions:** a checkbox column (with a select-all header)
  lets you pick any number of Tree-view lines; a bar then offers **Set Status**,
  **Set RFx**, **Clear Notes**, and **Delete** on just the selected lines, plus
  Clear selection. The selection is kept as you search, filter, and collapse.
- **Move before/after a chosen part:** instead of nudging a line one row at a
  time, pick **Move before…** or **Move after…** and choose the target part
  from a type-to-search list (item no · 3M part number · description). The line
  (with its sub-items) relocates next to that part — anywhere in the tree, so it
  can change nesting too. A part can't be moved into its own sub-tree.
- **Focus on one assembly:** rows that are assemblies (have children) show a
  small **filter icon** next to their part number (hover text: "Filter the tree
  to show only this assembly and its parts") that collapses the Tree view down
  to just that assembly and its sub-parts — hiding every sibling and parent.
  Item numbers keep their true path (e.g. 1.7.1.1). A banner names the focused
  assembly; move up one level with **↑ Up to Parent** (re-focuses the parent
  assembly; disabled at the top level), or clear it with the **Clear filter**
  button or the **Esc** key.
- **Data-quality flag:** lines sharing a 3M Part Number but with inconsistent
  Manufacturer, Commercial Part No, 3M Supplied, Description, RFx, or Status
  are highlighted, with an on-hover explanation of exactly what differs.
- **RFx details, without the clutter:** in Tree view, hovering an RFx cell
  shows a tooltip with its order details (PO, description, supplier, delivery,
  status), and focusing/clicking one fills a dedicated info panel above the
  table with the same details — so the rows stay clean. Works on inherited
  (Included-in-Parent) RFx cells too. Each entry in the RFx dropdown also
  carries its order's **Description** as hover text, so cryptic RFx codes are
  identifiable while picking one. (Native dropdowns now follow the light/dark
  theme via `color-scheme`, fixing the washed-out "inverse colors" popup.)
- **Focus on one assembly:** assembly rows carry a small **filter icon** (next
  to the part number) — the Tree view collapses to just that assembly and its
  sub-parts, hiding siblings and parents. Item numbers keep their true path;
  clear with the banner button or **Esc**.
- **Level color-coding:** Tree view rows are shaded by their depth in the
  hierarchy with a **monochrome gradient** — darkest at the top level,
  lightening as you go deeper (the same palette as the Excel export), so the
  structure reads at a glance. The tint adapts to light/dark theme, and the
  data-quality warning still takes precedence on flagged rows.
- **Excel-like copy/paste:** in Tree view, drag or shift-click to select a
  rectangle of cells, **Ctrl+C** to copy as tab-separated values, and **Ctrl+V**
  to paste a block from the top-left of the selection. Interoperates with real
  Excel. Read-only columns (Item No, derived PO, inherited RFx/Status) are
  skipped on paste.

## Parts catalog (backend only)

The standalone **Parts List tab was removed** (it wasn't useful in practice).
The parts catalog itself is retained as a backend feature — the `parts` table,
the `/api/parts` routes, and the BOM→catalog sync all stay — because it powers
BOM part-number autocomplete.

- **Stays in sync with the BOM automatically:** every BOM save adds or updates
  the parts it uses (keyed by 3M Part Number); assemblies also remember a
  snapshot of their child components. Parts added manually — or no longer in
  the BOM — are kept, never deleted.
- **Autocomplete on the BOM:** typing a 3M Part Number on a BOM line suggests
  matching catalog parts; picking one fills in the line's identity fields. If
  the part is an assembly, you're offered its remembered children as
  ready-made sub-items.

## Orders

- Full Orders tab: RFx, PO, Description, Supplier Name, Delivery Date, Status,
  **Price**.
- **Add Order** opens a form to enter all the order's details up front (RFx is
  required, Price optional), rather than dropping a blank row into the table.
- **Price per order** — each order has an editable **Price ($)** field (in the
  Add Order dialog and the order detail form), and the Orders panel shows a
  running **Total Cost** (the sum of every order's price) below the list,
  updating live as prices change. Price is included in the orders **Copy**.
- **Expand an order to see and edit its parts:** a toggle on each order row
  reveals the BOM parts on that RFx (aggregated by 3M part number, with a
  "N parts · Qty X" summary) inline, no page reload. **RFx**, **Status** and
  **Notes** are editable there — a change fans out to every underlying BOM line
  (with a confirm when more than one is affected) — and a **Clear Notes** button
  wipes the Notes on every part on that RFx. Changing a part's **RFx moves it to
  another order** (and re-derives its PO). This replaces the old RFx BOM view.
  Toolbar **Expand All / Collapse All** buttons open or close every order's
  parts at once.
- **"(none)" catch-all row:** BOM items with no RFx assigned used to be invisible
  on the Orders page. A synthetic **(none)** row now appears at the bottom of the
  table whenever any item lacks an RFx; expand it to see those items and assign
  each an RFx (which moves it to the matching order). It's display-only — not a
  stored order — and it's included in **Copy Table** and the read-only export.
- **Sort and filter** the Orders table: click a column header to sort
  (ascending/descending), and use the per-column **multi-select** filters
  (choose several values per column, OR-matched). Sorting and filtering affect
  the display only — the saved order sequence is unchanged.
- **Copy Table** copies the visible orders to the clipboard as tab-separated
  text for Excel — and now includes **each order's parts** (the same list the
  expander shows), indented one column beneath their order, whether or not the
  order is expanded.
- **Update Status** action pushes an order's status onto every BOM part on
  that RFx.
- **Renaming an RFx** on an order offers to carry every BOM line still on the
  old RFx over to the new one (re-deriving their PO), so lines are never
  silently orphaned.

## Excel import / export

- **Export** to a real `.xlsx` with sheets: Project Details (including a Date
  Exported row), BOM Tree (with Excel outline grouping), BOM Flat, BOM By RFx
  (grouped), and an Import sheet.
- **Level color-coding:** the BOM Tree sheet shades each row by its depth in
  the hierarchy (a monochrome gradient, dark→light; deeper levels reuse the last color), so the
  structure reads at a glance. A matching color key is added to the Project
  Details sheet. The Import sheet is left uncolored so it still round-trips. Key columns are centered; column widths
  auto-fit. The BOM By RFx group headers spread each piece — RFx, PO,
  description, supplier, delivery date, status, and the part/qty roll-up —
  across separate cells (not one merged cell). The **BOM (Flat)** and **BOM
  (By RFx)** sheets ship with Excel column-filter dropdowns on their header
  row.
- **Import** reads real `.xlsx` files (handles Excel's compression) from the
  Import sheet; the template matches the export format; any new RFx values are
  added to the Orders table automatically.
- **Export HTML** saves a single self-contained `.html` file that *is* the app,
  running **read-only** against the project's data embedded in the page — no
  server, database, or external requests, so it opens in any browser (even
  straight off disk). It looks and behaves like the live app — Tree/Flat views,
  search, filters, the BOM↔Orders spotlight, and Copy Table all work — but every
  cell (and the order detail form) is static text. Controls that need the server
  or editing are hidden (Refresh, Home, Settings, Import/Export, Close App, Add
  Order, + Add Item); the **theme toggle** and panel collapse still work. The
  **Bill of Materials** and **Orders** are included.

## Data storage & Excel connection

- Data moved from browser storage to a **SQLite database** (`data/app.db`) via
  `server.py`, so clearing the browser no longer affects data.
- **Excel data connection:** a live endpoint (`/api/data.json`, for Power
  Query "From Web", always current) and a JSON file written when the app
  **starts** and **stops** — not on every edit, so ongoing work never touches
  the (possibly shared) file. Both expose flat, spreadsheet-friendly `projects`
  / `orders` / `bomLines` tables. Discoverable via the Excel Data dialog; to
  refresh the file mid-session, restart the app.
- **Shareable data file:** the JSON file can be relocated out of the app folder
  onto a shared/network drive so others can query it, by setting `export_json`
  in `config.ini` (or the `BOM_EXPORT_PATH` environment variable); it defaults
  to `data/export.json`. The server stays `localhost`-only — only the file is
  shared. Writes are hardened (auto-created target folder, unique temp file +
  atomic rename, retry when the file is briefly locked). To make the on-stop
  write reliable for the windowless server, `stop-app.bat` triggers a graceful
  shutdown (`POST /api/shutdown`) and only force-kills as a fallback.

## Running the app / infrastructure

- **Batched saving (Save button).** Edits are now applied in memory and the
  header shows **"Unsaved changes"** with the **Save** button enabled — nothing
  is written to the server on every keystroke (that live-saving was the
  slowdown). Persist with **Save** (or **Ctrl/Cmd+S**). Unsaved work is
  auto-saved **every 15 minutes**, the browser **warns before you leave** with
  unsaved changes, **Refresh** confirms before discarding them, and **Close App**
  offers to save first.
- **Refresh button** in the project header re-pulls the project's data from the
  server and re-renders (keeping the current view, expand/collapse, and
  selection) — a manual fix for seeing a stale copy when another session has
  changed the data, since the page otherwise loads data only once.
- `start-app.bat` launches the server windowless (no leftover console window)
  and opens the app; `stop-app.bat` stops it.
- **Close App button** on every screen (project selector and project detail)
  stops the local server — via the same `POST /api/shutdown` graceful shutdown
  that `stop-app.bat` triggers (a web page can't launch a `.bat` directly), so
  the final data snapshot is still written — then closes the window (works in
  the Chrome app-mode / installed-PWA window; a normal tab shows a "you can
  close this window" message instead). If **Google Chrome** is installed
  it opens in Chrome **app mode** (`--app=`) — a clean, standalone window with
  no tabs or address bar that carries the app's own icon — otherwise it falls
  back to the default browser.
- **App icon, install, and taskbar shortcut:** the app ships an icon
  (`favicon.ico` + `icons/`) and a web manifest (`manifest.webmanifest`), so
  Chrome/Edge offer **Install** — giving it a standalone window with its own
  taskbar and Start-menu icon. `Create-mBOM-Shortcut.ps1` also makes Desktop
  and Start-menu shortcuts (with the icon); pin either to the taskbar. The
  server now serves `favicon.ico` and `.webmanifest`
  (as `application/manifest+json`).
- **Standalone `.exe` (`mBOM.exe`):** a one-file PyInstaller build that bundles
  Python, the server, and the whole web app. Double-clicking it (or the
  shortcut) **starts the server itself and opens the browser** — no separate
  Python install or PATH needed. `server.py` is freeze-aware: static assets run
  from the bundle, while the database, `config.ini`, logs and export file live
  next to the `.exe` (so data persists between runs). Built via
  `mbom_launcher.py` (the entry point). `Create-mBOM-Shortcut.ps1` targets the
  `.exe` when present, else falls back to `start-app.bat`.
- **Code signing (`sign.ps1`):** signs `mBOM.exe` with Authenticode + an
  RFC-3161 timestamp. Defaults to a self-signed test cert (proves the pipeline;
  **not** trusted by Windows/antivirus); pass `-Pfx`/`-Password` or
  `-Thumbprint` to sign with a real CA code-signing certificate — required to
  actually avoid SmartScreen/AV "unknown publisher" warnings.
- Fixed a bug where pages loaded blank or intermittently — the server now
  speaks HTTP/1.1 and refuses to double-bind its port.
- `README.md` documents setup and the Excel connection.
